from django.apps import AppConfig

# Application configuration of app 'athletes'
class AthletesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'athletes'
